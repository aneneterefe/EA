package com.lab13_01.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1301ApplicationTests {

	@Test
	void contextLoads() {
	}

}
