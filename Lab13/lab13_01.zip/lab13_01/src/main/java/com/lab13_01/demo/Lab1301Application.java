package com.lab13_01.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1301Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab1301Application.class, args);
	}

}
